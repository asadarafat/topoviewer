# Follow a packet through the fabric

Open the .tvstudio file with Project menu > Open archive in TopoViewer Studio. It opens the initial view. The YAML files include the documented alternate states, where provided.

Each topology is paired with stylesheet.yaml unless a state-specific stylesheet is supplied. These are authored examples, not live telemetry or routing simulation.

Guide: https://asadarafat.github.io/topoviewer/docs/mkdocs/topoviewer/examples/use-cases/follow-a-packet/
